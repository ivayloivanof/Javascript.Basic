var students = "[" +
					"{'name' : 'Пешо','score' : 91}," +
					"{'name' : 'Лилия','score' : 290}," +
					"{'name' : 'Алекс','score' : 343}," +
					"{'name' : 'Габриела','score' : 400}," +
					"{'name' : 'Жичка','score' : 70}" +
				"]";

function increasingScores() {
	/*
	students.sort(function(a, b) {
		return (a.name) - (b.name);
	});
	*/
}

increasingScores();


/*
[
	{'name' : 'Пешо','score' : 91},
	{'name' : 'Лилия','score' : 290},
	{'name' : 'Алекс','score' : 343},
	{'name' : 'Габриела','score' : 400},
	{'name' : 'Жичка','score' : 70}
]




 [
	 {"name":"Алекс","score":377.3,"hasPassed":true},
	 {"name":"Габриела","score":440,"hasPassed":true},
	 {"name":"Лилия","score":319,"hasPassed":true},
	 {"name":"Пешо","score":100.1,"hasPassed":true}
 ]
*/